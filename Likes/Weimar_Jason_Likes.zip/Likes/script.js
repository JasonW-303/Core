var likeNumber1 = document.querySelector('#like-count-num1');

function likeIncrease1(){
    likeNumber1.textContent++;
}

var likeNumber2 = document.querySelector('#like-count-num2');

function likeIncrease2(){
    likeNumber2.textContent++;
}

var likeNumber3 = document.querySelector('#like-count-num3');

function likeIncrease3(){
    likeNumber3.textContent++;
}