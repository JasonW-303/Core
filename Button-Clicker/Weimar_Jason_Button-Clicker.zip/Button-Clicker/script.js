function deleteElement(elem){
    elem.remove();
}

function changeText(elem){
    elem.textContent = 'Login';
}